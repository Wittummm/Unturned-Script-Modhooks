using UnityEngine;

namespace SDG.Unturned;

// Does nothing externally, only comments for your Unity project

[AddComponentMenu("Unturned/Comment")]
public class CommentComponent : MonoBehaviour
{
    public string message;
}
