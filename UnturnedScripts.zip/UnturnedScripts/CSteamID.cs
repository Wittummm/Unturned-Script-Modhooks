// - Wittummm, idk what this is but olie304 has it for some reason :shrug:.

// Required for classes that use CSteamID
namespace Steamworks
{
    public struct CSteamID
    {
        public ulong m_SteamID;
    }
}